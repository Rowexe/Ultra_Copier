Thanks for downloading from Rowexe!

Modules (python) used:

colorama
os
shutil
zipfile
time
random for randint
from tkinter for filedialog to be opened as openas

Changelog:

Fixed a bug where if you upload a file and then try to exit via the inbuild exit, it will glitch out (Thanks to PPCGamer for emailing and telling this bug)
Added more exception handling

