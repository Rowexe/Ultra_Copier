Thanks for downloading from Rowexe!

Modules (python) used:

colorama
os
shutil
zipfile
time
random for randint
from tkinter for filedialog to be opened as openas